class A{
public static void main(String arg[]){
}

}